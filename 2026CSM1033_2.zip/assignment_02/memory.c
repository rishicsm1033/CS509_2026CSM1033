#include <stdio.h>
#include <string.h>
#include "memory.h"

unsigned char Instruction[256];
unsigned char Data[4096];

/* Load hexadecimal bytes from a file  */

static int load_file(const char *filename,unsigned char *memory,int size)
{
    FILE *fp;
    unsigned int value;
    int index = 0;
    fp = fopen(filename, "r");
    if (fp == NULL)
        return -1;
    while (index < size &&
           fscanf(fp, "%x", &value) == 1)
    {
        memory[index] =
            (unsigned char)(value & 0xFF);
        index++;
    }
    fclose(fp);
    return 0;
}
/* Save data memory*/
static int save_file(const char *filename,unsigned char *memory,int size)
{
    FILE *fp;
    int i;
    fp = fopen(filename, "w");
    if (fp == NULL)
        return -1;
    for (i = 0; i < size; i += 4)
    {
        fprintf(fp,
                "%02X %02X %02X %02X\n",memory[i],memory[i + 1],memory[i + 2],memory[i + 3]);
    }
  fclose(fp);
    return 0;
}
/* Initialize memory  */
int initialize()
{
    memset(Instruction,0,sizeof(Instruction));
    memset(Data,0,sizeof(Data));
    /* Load program bytecode */
    if (load_file("program.byte",Instruction,sizeof(Instruction)) != 0)
    {
        printf("Cannot open program.byte\n");
        return -1;
    }
    /* data.byte is allowed to be absent for programsthat don't require preinitialized data.*/
    load_file("data.byte",Data,sizeof(Data));
    return 0;
}
/* Finalize memory  */
void finalize()
{
    if (save_file("data.byte",
                  Data,
                  sizeof(Data)) != 0)
    {
        printf("Cannot write data.byte\n");
    }
}
#include <stdio.h>
#include "processor.h"
#include "memory.h"
#include <stdint.h>
int Register[256];
int PC;
int opcode;
int destination;
int source1;
int source2;
int end_of_simulation = 0;
int Z, N, C, V;
static uint32_t read_u32(const unsigned char *p)
{
    return ((uint32_t)p[0]) | ((uint32_t)p[1] << 8) |((uint32_t)p[2] << 16) |((uint32_t)p[3] << 24);
}
static void write_u32(unsigned char *p,uint32_t value)
{
    p[0] = value & 0xFF;
    p[1] = (value >> 8) & 0xFF;
    p[2] = (value >> 16) & 0xFF;
    p[3] = (value >> 24) & 0xFF;
}
void reset()
{
    for (int i = 0; i < 256; i++)
    {
        Register[i] = 0;
    }
    PC = 0;
    Z = 0;
    N = 0;
    C = 0;
    V = 0;
    end_of_simulation = 0;
}
void fetch()
{
    if (PC + 3 >= 256)
    {
        printf("Instruction memory overflow\n");
        end_of_simulation = 1;
        return;
    }
    opcode = Instruction[PC];
    destination = Instruction[PC + 1];
    source1 = Instruction[PC + 2];
    source2 = Instruction[PC + 3];
    PC = PC + 4;
}
void decode()
{
}

        static int branch_taken(uint8_t condition)
{
    switch (condition)
    {
        case 0x0:
            return Z == 1;              /* BEQ */

        case 0x1:
            return Z == 0;              /* BNE */

        case 0x2:
            return N == 1;              /* BMI */

        case 0x3:
            return N == 0;              /* BPL */

        case 0x4:
            return C == 1;              /* BCS */

        case 0x5:
            return C == 0;              /* BCC */

        case 0x6:
            return V == 1;              /* BVS */

        case 0x7:
            return V == 0;              /* BVC */

        case 0x8:
            return C == 1 && Z == 0;    /* BHI */

        case 0x9:
            return C == 0 || Z == 1;    /* BLS */

        case 0xA:
            return N == V;              /* BGE */

        case 0xB:
            return N != V;              /* BLT */

        case 0xC:
            return Z == 0 && N == V;    /* BGT */

        case 0xD:
            return Z == 1 || N != V;    /* BLE */

        case 0xE:
            return 1;                   /* BAL */

        default:
            return 0;
    }
}

void addflags(int a, int b, int result)
{
    Z = (result == 0);
    N = (result < 0);
    C = 0;
    V = 0;
    unsigned int u1 = (unsigned int)a;
    unsigned int u2 = (unsigned int)b;
    unsigned int u3 = (unsigned int)result;
    if (u3 < u1 || u3 < u2)
    {
        C = 1;
    }
    if ((a > 0 && b > 0 && result < 0) ||
        (a < 0 && b < 0 && result > 0))
    {
        V = 1;
    }
}
void subflags(int a, int b, int result)
{
    Z = (result == 0);
    N = (result < 0);
    C = 0;
    V = 0;
    if (a >= b)
    {
        C = 1;
    }
    if ((a > 0 && b < 0 && result < 0) ||
        (a < 0 && b > 0 && result > 0))
    {
        V = 1;
    }
}
void execute()
{
    switch (opcode)
    {
        case 0x00:
        {
            end_of_simulation = 1;
            break;
        }
        /*  x1 = x2 + x3 */
        case 0x01:
        {
            int a = Register[source1];
            int b = Register[source2];
            Register[destination] = a + b;
            addflags(a, b, Register[destination]);
            break;
        }
        /*  x1 = x2 - x3 */
        case 0x02:
        {
            int a = Register[source1];
            int b = Register[source2];
            Register[destination] = a - b;
            subflags(a, b, Register[destination]);
            break;
        }
        /*  x1 = x2 * x3 */
        case 0x03:
        {
            Register[destination] =Register[source1] * Register[source2];
            break;
        }
        /*  x1 = x2 / x3 */
        case 0x04:
        {
            Register[destination] =Register[source1] / Register[source2];
            break;
        }
        /* LOAD x1 = [x2] */
        case 0x05:
        {
           uint32_t address;

            if (source1 != 0)
                address = Register[source1];
            else
                address = source2;
            if (address > 4092)
            {
                printf("Memory read outside Data memory\n");
                end_of_simulation = 1;
                break;
            }
            Register[destination] =read_u32(&Data[address]);
        }
        /*STORE [x1] = x2*/
        case 0x06:
        {
            uint32_t address =
                Register[source2];

            if (address > 4092)
            {
                printf("Memory write outside Data memory\n");
                end_of_simulation = 1;
                break;
            }

            write_u32(&Data[address],
                      Register[source1]);

            break;
        }
        /*x1 =10*/
        case 0x07:
        {
            Register[destination] = source2;
            break;
        }
        /* x1 = x2 + 10*/
        case 0x09:
        {
            int a = Register[source1];
            int b = source2;
            Register[destination] = a + b;
            addflags(a, b, Register[destination]);
            break;
        }
        /*x1 = x2 - 10*/
        case 0x0A:
        {
            int a = Register[source1];
            int b = source2;
            Register[destination] = a - b;
            subflags(a, b, Register[destination]);
            break;
        }
         /*x1 = x2 * 10*/
        case 0x0B:
        {
            Register[destination] =Register[source1] * source2;

            break;
        }
         /*x1 = x2 / 10*/
        case 0x0C:
        {
            Register[destination] =Register[source1] / source2;
            break;
        }   
        /*Memory write [address] = register */ 
        case 0x0E:
        {
            uint32_t address;

            if (source2 < 256)
            {
                /*
                 * Compiler encoding:
                 * src2 is the address-register number.
                 */
                address = Register[source2];
            }
            else
            {
                address = source2;
            }
            if (address > 4092)
            {
                printf("Memory write outside Data memory\n");
                end_of_simulation = 1;
                break;
            }
            Data[address]=Register[destination];
            break;
        }
        case 0x0F:
            Register[destination] =Register[source2];
            break;
        default:
            if ((opcode & 0xF0) == 0x10)
            {
                uint8_t condition = opcode & 0x0F;
                int8_t offset =(int8_t)source2;
                if (branch_taken(condition))
                {
                    /*
                     * PC currently points to the next
                     * instruction because fetch() already
                     * incremented it by 4.
                     */
                    PC =
                        (uint32_t)
                        ((int32_t)PC +
                         (int32_t)offset -
                         4);
                }
            }
            else
            {
                printf("Unknown opcode: %02X\n", opcode);
                end_of_simulation = 1;
            }

            break;
    }
}
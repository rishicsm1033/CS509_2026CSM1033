#ifndef PROCESSOR_H
#define PROCESSOR_H

extern int Register[256];
extern int PC;
extern int end_of_simulation;
extern int Z;
extern int N;
extern int C;
extern int V;


void reset();
void fetch();
void decode();
void execute();
#endif
#ifndef COMPILER_H
#define COMPILER_H

int compile(const char *source_file, const char *bytecode_file);

#endif
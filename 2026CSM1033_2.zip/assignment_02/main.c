#include "compiler.h"
#include "memory.h"
#include "processor.h"
#include <stdio.h>

int main(int argc, char **argv)
{
    if (argc < 2)
    {
        printf("Usage: %s <source_file>\n", argv[0]);
        return 1;
    }

    /* Compile source program */
    if (compile(argv[1], "program.byte") != 0)
    {
        printf("Compilation failed.\n");
        return 1;
    }

    /* Load program.byte */
    if (initialize() != 0)
    {
        printf("Memory initialization failed.\n");
        return 1;
    }

    reset();

    while (!end_of_simulation)
    {
        fetch();

        if (end_of_simulation)
            break;

        decode();
        execute();
    }

    finalize();

    return 0;
}
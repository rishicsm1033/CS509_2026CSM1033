#include <ctype.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "compiler.h"

#define MAX_LINES 1024
#define MAX_LABELS 256

typedef struct
{
    char name[64];
    int instruction_index;
} Label;

typedef struct
{
    char text[256];
    int line_no;
} SourceLine;

static Label labels[MAX_LABELS];
static int label_count = 0;
//Remove leading and trailing whitespace                    
static void trim(char *s)
{
    char *p = s;
    while (isspace((unsigned char)*p))
        p++;
    if (p != s)
        memmove(s, p, strlen(p) + 1);
    size_t n = strlen(s);
    while (n > 0 && isspace((unsigned char)s[n - 1]))
    {
        s[n - 1] = '\0';
        n--;
    }
}
//Remove comments                                           
//Anything after % is ignored                              
static void strip_comment(char *s)
{
    char *p = strchr(s, '%');
    if (p != NULL)
        *p = '\0';
}
// Parse register x0 ... x255                                
static int parse_reg(const char *s)
{
    char *end;
    long value;
    if (s[0] != 'x' && s[0] != 'X')
        return -1;
    value = strtol(s + 1, &end, 10);
    if (*end != '\0')
        return -1;
    if (value < 0 || value > 255)
        return -1;
    return (int)value;
}
//Parse constant 0 ... 255                                  
static int parse_const(const char *s)
{
    char *end;
    long value;
    errno = 0;
    value = strtol(s, &end, 0);
    if (errno != 0)
        return -1;
    if (*end != '\0')
        return -1;
    if (value < 0 || value > 255)
        return -1;
    return (int)value;
}
// Find label                                                 
static int label_find(const char *name)
{
    int i;
    for (i = 0; i < label_count; i++)
    {
        if (strcmp(labels[i].name, name) == 0)
            return labels[i].instruction_index;
    }
    return -1;
}
// Check label syntax                                        
// Labels must start with .                                  
// Remaining characters are alphanumeric                    
static int valid_label(const char *s)
{
    int i;
    if (s[0] != '.')
        return 0;
    if (s[1] == '\0')
        return 0;
    for (i = 1; s[i] != '\0'; i++)
    {
        if (!isalnum((unsigned char)s[i]))
            return 0;
    }
    return 1;
}
// Tokenize text                                              
static int tokenize(char *s, char *tokens[], int max_tokens)
{
    int count = 0;
    char *token = strtok(s, " \t\r\n,=[]");
    while (token != NULL && count < max_tokens)
    {
        tokens[count++] = token;
        token = strtok(NULL, " \t\r\n,=[]");
    }
    return count;
}
// Branch check                                               
static int is_branch(const char *op)
{
    const char *names[] ={"BAL","BEQ","BNE","BMI","BPL","BCS","BCC","BVS","BVC","BHI","BLS","BGE","BLT","BGT","BLE"};
    int i;
    for (i = 0; i < 15; i++)
    {
        if (strcmp(op, names[i]) == 0)
            return 1;
    }
    return 0;
}
// Return branch condition code                              
static int branch_code(const char *op)
{
    const char *names[] ={"BEQ",
        "BNE",
        "BMI",
        "BPL",
        "BCS",
        "BCC",
        "BVS",
        "BVC",
        "BHI",
        "BLS",
        "BGE",
        "BLT",
        "BGT",
        "BLE",
        "BAL"};
    int i;
    for (i = 0; i < 15; i++)
    {
        if (strcmp(op, names[i]) == 0)
            return i;
    }
    return -1;
}
//First pass: read source and collect labels                
static int parse_source(SourceLine *lines,int *count,const char *filename)
{
    FILE *fp;
    char buffer[256];
    int physical_line = 0;
    fp = fopen(filename, "r");
    if (fp == NULL)
    {
        printf("Cannot open source file %s\n", filename);
        return -1;
    }
    while (fgets(buffer, sizeof(buffer), fp) != NULL)
    {
        physical_line++;
        strip_comment(buffer);
        trim(buffer);
        if (buffer[0] == '\0')
            continue;
        //Label 
        if (buffer[0] == '.')
        {
            if (!valid_label(buffer))
            {
                printf("Invalid label at line %d\n",physical_line);
                fclose(fp);
                return -1;
            }
            if (label_find(buffer) != -1)
            {
                printf("Duplicate label at line %d\n",physical_line);
                fclose(fp);
                return -1;
            }
            if (label_count >= MAX_LABELS)
            {
                printf("Too many labels\n");
                fclose(fp);
                return -1;
            }
            strcpy(labels[label_count].name, buffer);
            labels[label_count].instruction_index = *count;
            label_count++;
            continue;
        }
        if (*count >= MAX_LINES)
        {
            printf("Program too large\n");
            fclose(fp);
            return -1;
        }
        strcpy(lines[*count].text, buffer);
        lines[*count].line_no = physical_line;
        (*count)++;
    }
    fclose(fp);
    return 0;
}
/* Write one bytecode instruction*/
static void emit(FILE *out,uint8_t opcode,uint8_t dest,uint8_t src1,uint8_t src2)
{
    fprintf(out,"%02X %02X %02X %02X\n",opcode,dest,src1,src2);
}
/* Compile one source line */
static int compile_line(FILE *out,SourceLine *line,
int instruction_index)
{
    char buffer[256];
    char lhs[128];
    char rhs[128];
    char *equal;
    char *tokens[8];
    int destination;
    strcpy(buffer, line->text);
    /* Branch instructions                                   */
    if (is_branch(strtok(buffer, " \t")))
    {
        char temp[256];
        char *op;
        char *label;
        strcpy(temp, line->text);
        op = strtok(temp, " \t");
        label = strtok(NULL, " \t");
        if (label == NULL)
        {
            printf("Invalid branch at line %d\n",
                   line->line_no);
            return -1;
        }
        int target = label_find(label);
        if (target == -1)
        {
            printf("Unknown label %s at line %d\n", label,line->line_no);
            return -1;
        }
        int code = branch_code(op);
        int offset =
            (target - instruction_index) ;
        if (offset < -128 || offset > 127)
        {
            printf("Branch offset too large at line %d\n",
                   line->line_no);
            return -1;
        }
        emit(out,
             (uint8_t)(0x10 + code),
             0,
             0,
             (uint8_t)(int8_t)offset);
        return 0;
    }
        /* Find '='                                               */
    equal = strchr(line->text, '=');
    if (equal == NULL)
    {
        printf("Invalid statement at line %d\n",
               line->line_no);
        return -1;
    }    
    /* Extract LHS                                            */
    {
        size_t length =(size_t)(equal - line->text);
        if (length >= sizeof(lhs))return -1;
        memcpy(lhs,line->text,length);
        lhs[length] = '\0';
        strcpy(rhs, equal + 1);
        trim(lhs);
        trim(rhs);
    }
    /* Memory write [address] = register */
    if (lhs[0] == '[')
    {
        char address[64];
        int source_reg;
        int address_reg;
        int address_const;
        if (sscanf(lhs,"[%63[^]]]",address) != 1)
        {
            printf("Invalid memory write at line %d\n",line->line_no);
            return -1;
        }
        trim(address);
        trim(rhs);
        source_reg = parse_reg(rhs);
        address_reg = parse_reg(address);
        address_const = parse_const(address);
        if (source_reg < 0)
        {
            printf("Memory write requires register source ""at line %d\n",line->line_no);
            return -1;
        }
        if (address_reg >= 0)
        {
            emit(out,0x0E,source_reg,0,address_reg);
            return 0;
        }
        if (address_const >= 0)
        {
            emit(out,0x0E,source_reg,0,address_const);
            return 0;
        }
        printf("Invalid memory address at line %d\n",line->line_no);
        return -1;
    }
    /* Destination register*/
    destination = parse_reg(lhs);
    if (destination < 0)
    {
        printf("Invalid destination at line %d\n",line->line_no);
        return -1;
    }
    /* Memory read x1 = [x2] x1 = [10] */
    if (rhs[0] == '[')
    {
        char address[64];
        int address_reg;
        int address_const;
        if (sscanf(rhs,
                   "[%63[^]]]",
                   address) != 1)
        {
            printf("Invalid memory read at line %d\n",
                   line->line_no);
            return -1;
        }
        trim(address);
        address_reg = parse_reg(address);
        address_const = parse_const(address);
        if (address_reg >= 0)
        {
            emit(out,
                 0x05,
                 destination,
                 address_reg,
                 0);

            return 0;
        }
        if (address_const >= 0)
        {
            emit(out,
                 0x05,
                 destination,
                 0,
                 address_const);

            return 0;
        }
        printf("Invalid memory address at line %d\n",
               line->line_no);

        return -1;
    }
    /* Arithmetic / data movement */
    {
        char copy[128];
        char *operand1;
        char *operator;
        char *operand2;
        int r1;
        int r2;
        int constant;
        strcpy(copy, rhs);
        operand1 = strtok(copy, " \t");
        operator = strtok(NULL, " \t");
        operand2 = strtok(NULL, " \t"); 
        /* x1 = x2 + x3 ,x1 = x2 + 10 */
        if (operand1 != NULL &&operator != NULL &&operand2 != NULL)
        {
            r1 = parse_reg(operand1);
            r2 = parse_reg(operand2);
            constant = parse_const(operand2);

            if (r1 < 0)
            {
                printf("Invalid first operand at line %d\n",
                       line->line_no);
                return -1;
            }
            uint8_t opcode_register;
            uint8_t opcode_constant;

            if (strcmp(operator, "+") == 0)
            {
                opcode_register = 0x01;
                opcode_constant = 0x09;
            }
            else if (strcmp(operator, "-") == 0)
            {
                opcode_register = 0x02;
                opcode_constant = 0x0A;
            }
            else if (strcmp(operator, "*") == 0)
            {
                opcode_register = 0x03;
                opcode_constant = 0x0B;
            }
            else if (strcmp(operator, "/") == 0)
            {
                opcode_register = 0x04;
                opcode_constant = 0x0C;
            }
            else
            {
                printf("Unknown operator at line %d\n",line->line_no);
                return -1;
            }
            if (r2 >= 0)
            {
                emit(out,opcode_register,destination,r1,r2);
                return 0;
            }
            if (constant >= 0)
            {
                emit(out,opcode_constant,destination,r1,constant);
                return 0;
            }
            printf("Invalid operand at line %d\n",line->line_no);
            return -1;
        }
        /*x1 = 10 */
        constant = parse_const(rhs);

        if (constant >= 0)
        {
            emit(out,0x07,destination,0,constant);
            return 0;
        }
     /* x1 = x2 */
        r1 = parse_reg(rhs);
        if (r1 >= 0)
        {
            emit(out,0x0F,destination,0,r1);
                 return 0;
        }
    }
printf("Cannot compile line %d: %s\n",line->line_no,line->text);
    return -1;
}
/* Main compiler function */
int compile(const char *source_file,const char *bytecode_file)
{
    SourceLine lines[MAX_LINES];
    int line_count = 0;
    int i;
    FILE *out;
    label_count = 0;
    if (parse_source(lines,&line_count,source_file) != 0)
    {
        return -1;
    }
    out = fopen(bytecode_file, "w");
    if (out == NULL)
    {
        printf("Cannot create %s\n",
               bytecode_file);

        return -1;
    }
    for (i = 0; i < line_count; i++)
    {
        if (compile_line(out,&lines[i],i) != 0)
        {
            fclose(out);
            return -1;
        }
    }
    /* Opcode 0 terminates execution */
    fprintf(out, "00 00 00 00\n");
    fclose(out);
    return 0;
}